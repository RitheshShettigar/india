### All-Indian-States-With-Districts-JSON-List

JSON file having list of all Indian states with their districts

Making data available in .json file as it is easy to import and use JSON in python / java / php or any other project related to web / android / ios etc.  
